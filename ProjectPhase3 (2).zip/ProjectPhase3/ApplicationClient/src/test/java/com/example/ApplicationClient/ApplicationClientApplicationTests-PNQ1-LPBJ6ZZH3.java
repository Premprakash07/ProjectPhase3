package com.example.ApplicationClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
