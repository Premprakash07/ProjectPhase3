package com.example.AccountsServiceApplication.controller;

import com.example.AccountsServiceApplication.exception.AccountNotFound;
import com.example.AccountsServiceApplication.models.AccountInfo;
import com.example.AccountsServiceApplication.services.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// Controllers for accounts
@RestController
@RequestMapping("/accounts")
public class AccountsController {

//    Instance of account service
    @Autowired
    private AccountService accountService;

//    Adds accounts
    @PostMapping("/add")
    public ResponseEntity<Object> addAccount(@RequestBody AccountInfo accountInfo) {
        int res =  this.accountService.addAccount(accountInfo);
        return new ResponseEntity<>(res, HttpStatus.CREATED);
    }

//    Gets account details
    @GetMapping("/get/{accNo}")
    public ResponseEntity<AccountInfo> getAccount(@PathVariable("accNo") int accNo) throws AccountNotFound {
        AccountInfo accountInfo =  this.accountService.getAccount(accNo);
        return new ResponseEntity<>(accountInfo, HttpStatus.OK);
    }

//    updates Account details
    @PutMapping("/update")
    public String updateAccount(@RequestBody AccountInfo accountInfo) throws AccountNotFound {
        return this.accountService.updateAccount(accountInfo);
    }

//    Delete account details
    @DeleteMapping("/delete/{username}")
    public ResponseEntity<Object> deleteAccount(@PathVariable("username") String username) throws AccountNotFound {
        String res = this.accountService.deleteAccount(username);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

}
