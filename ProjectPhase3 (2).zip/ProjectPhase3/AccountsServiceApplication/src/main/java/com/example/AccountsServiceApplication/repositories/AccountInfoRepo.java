package com.example.AccountsServiceApplication.repositories;

import com.example.AccountsServiceApplication.models.AccountInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AccountInfoRepo extends JpaRepository<AccountInfo, Integer> {
    Optional<AccountInfo> findByEmail(String email);
}
