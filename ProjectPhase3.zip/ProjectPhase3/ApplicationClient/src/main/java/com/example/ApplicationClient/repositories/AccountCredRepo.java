package com.example.ApplicationClient.repositories;

import com.example.ApplicationClient.model.AccountCred;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// respository for account credentials
@Repository
public interface AccountCredRepo extends JpaRepository<AccountCred, Integer> {

    AccountCred findByAccNo(int accNo);
}
