package com.example.ApplicationClient.controller;

import com.example.ApplicationClient.configuration.JwtTokenUtil;
import com.example.ApplicationClient.model.AccountCred;
import com.example.ApplicationClient.repositories.AccountCredRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

//// Class tha handles auth controller
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AccountCredRepo accountCredRepo;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

//    logs in into the account
    @PostMapping("/login")
    public ResponseEntity<String> login(HttpSession session, @RequestParam int accNo,
                                        @RequestParam String password) {
        AccountCred accountCred = this.accountCredRepo.findByAccNo(accNo);
        if (accountCred != null) {
            if (accountCred.getPassword().equals(password)) {


                String token = this.jwtTokenUtil.generateToken(new User(Integer.toString(accNo), password, new ArrayList<>()));

                return new ResponseEntity<String>(token ,HttpStatus.OK);
            }
            return new ResponseEntity<String>("Bad Credentials", HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity<String>("user not found", HttpStatus.UNAUTHORIZED);
    }

//    logs out of the account
    @PostMapping("/logout")
    public ResponseEntity<Object> logout(HttpSession session) {
        session.setAttribute("userToken", null);
        return new ResponseEntity<Object>("Logged out", HttpStatus.OK);
    }
}
