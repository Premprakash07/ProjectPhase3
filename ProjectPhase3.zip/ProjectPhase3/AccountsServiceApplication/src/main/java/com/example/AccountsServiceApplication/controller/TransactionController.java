package com.example.AccountsServiceApplication.controller;

import com.example.AccountsServiceApplication.exception.AccountNotFound;
import com.example.AccountsServiceApplication.services.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// Controller for the transaction
@RestController
@RequestMapping("/transaction")
public class TransactionController {

//    Instance of Transaction service
    @Autowired
    private TransactionService transactionService;

//    withdraws money from the account
    @PostMapping("/withdraw/{accNo}/{amount}")
    public ResponseEntity<String> withdraw(@PathVariable("accNo") int accNo,
    @PathVariable("amount") double amount) throws Exception {
        System.out.println(accNo);
        System.out.println(amount);
        return new ResponseEntity<String>(this.transactionService.withdraw(accNo, amount),HttpStatus.OK);
    }

//    deposits money into the account
    @PostMapping("/deposit/{accNo}/{amount}")
    public ResponseEntity<String> deposit(@PathVariable("accNo") int accNo,
    @PathVariable("amount") double amount) throws Exception {
        return new ResponseEntity<String>(this.transactionService.deposit(accNo, amount), HttpStatus.OK);
    }

//    creates a transfer
    @PostMapping("/transfer/{type}/{fromAcc}/{toAcc}/{amount}")
    public ResponseEntity<String> transfer(@PathVariable("type") String type, @PathVariable("toAcc") int toAcc,
                      @PathVariable("fromAcc") int fromAcc, @PathVariable("amount") double amount) throws Exception {
        return new ResponseEntity<String>(this.transactionService.transfer(type, amount, fromAcc, toAcc),
                HttpStatus.OK);
    }

//    gets transaction of a particular account
    @GetMapping("/getallbyacc/{accNo}")
    public ResponseEntity<Object> getallByAccNo(@PathVariable("accNo") int accNo) throws AccountNotFound {
        return new ResponseEntity<Object>(this.transactionService.getAllTransactionByAccNo(accNo), HttpStatus.OK);
    }
}
